package ir.gandomzar.winner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;
import java.util.Random;

public  class  MainActivity extends AppCompatActivity {


    EditText txt_main_name_add;
    Button btn_main_save, btn_main_show,btn_main_winner;
    DBHelper dbm;
    List<MyListData> myListDataq;
    MyListData myListData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt_main_name_add = findViewById(R.id.txt_main_name_add);
        btn_main_save = findViewById(R.id.btn_main_save);
        btn_main_show=findViewById(R.id.btn_main_show);
        btn_main_winner=findViewById(R.id.btn_main_winner);
        dbm = new DBHelper(this);
        SQLiteDatabase db = dbm.getWritableDatabase();
        if (db != null && db.isOpen()) {
            db.close();
        }

        btn_main_winner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Random random=new Random();
                int rn1=random.nextInt(myListDataq.size());
                String NameWiner=myListDataq.get(rn1).getName();
                Toast.makeText(MainActivity.this, NameWiner+"\n"+"برنده خوش شانس", Toast.LENGTH_LONG).show();
            }
        });




        btn_main_show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                extracted();

            }
        });


        btn_main_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(txt_main_name_add.getText().toString())) {

                    Toast.makeText(MainActivity.this, "Plase Enter Name...", Toast.LENGTH_SHORT).show();
                } else {

                    myListData = new MyListData(txt_main_name_add.getText().toString(), 0);
                    dbm.insertKarbr(myListData);
                    Toast.makeText(MainActivity.this, "Insert Susesessss", Toast.LENGTH_SHORT).show();
                    txt_main_name_add.setText("");
                    extracted();


                }
            }
        });





    }


    public  void extracted() {
        myListDataq = dbm.getAllKarbaran();
        RecyclerView recyclerView = findViewById(R.id.recycler_karbaran);
        AdapterWiner adapter = new AdapterWiner(myListDataq);
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerView.setAdapter(adapter);
    }
}