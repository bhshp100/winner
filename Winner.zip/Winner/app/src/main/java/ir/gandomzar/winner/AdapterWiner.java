package ir.gandomzar.winner;

import android.content.DialogInterface;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AdapterWiner extends RecyclerView.Adapter<AdapterWiner.ViewHolder> {
    private List<MyListData> myListData;

    public AdapterWiner(List<MyListData> myListData) {
        this.myListData = myListData;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.list_item_karbran, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        MyListData listData=myListData.get(position);
        holder.txt_list_name.setText(listData.getName());
        holder.txt_list_shans.setText(String.valueOf(listData.getWinner()));
        holder.rlt_asli.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                AlertDialog.Builder dialog=new AlertDialog.Builder(view.getContext());
                dialog.setTitle("حذف")
                        .setMessage("Are You delte  :"+listData.getName())
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Toast.makeText(view.getContext(),"Yes:"+String.valueOf(listData.getKid()), Toast.LENGTH_SHORT).show();
                                DBHelper db=new DBHelper(view.getContext());
                                SQLiteDatabase dbs=db.getWritableDatabase();
                                db.deleteRaw(listData.getKid());


                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Toast.makeText(view.getContext(),"No..", Toast.LENGTH_SHORT).show();
                            }
                        }).show();
                return false;
            }
        });

    }

    @Override
    public int getItemCount() {
        return myListData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView txt_list_name,txt_list_shans;
        RelativeLayout rlt_asli;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txt_list_name=itemView.findViewById(R.id.txt_list_name);
            txt_list_shans=itemView.findViewById(R.id.txt_list_shans);
            rlt_asli=itemView.findViewById(R.id.rlt_asli);

        }
    }
}
