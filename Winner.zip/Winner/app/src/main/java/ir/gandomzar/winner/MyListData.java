package ir.gandomzar.winner;

public class MyListData {
    private long kid;

    public long getKid() {
        return kid;
    }

    public void setKid(long kid) {
        this.kid = kid;
    }

    public MyListData(String name, int winner,long kid) {
        this.kid = kid;
        this.name = name;
        this.winner = winner;
    }

    private String name;
    private int winner;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getWinner() {
        return winner;
    }

    public void setWinner(int winner) {
        this.winner = winner;
    }

    public MyListData(String name, int winner) {
        this.name = name;
        this.winner = winner;
    }


}
