package ir.gandomzar.winner;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "winner_db.db";
    private static final int DB_VERSION = 1;
    private static final String CMD = "CREATE TABLE IF NOT EXISTS karbaran('kid' INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,'name' TEXT,'winner' INTEGER)";

    public DBHelper(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CMD);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }



    public void insertKarbr(MyListData listData) {
        SQLiteDatabase idb = this.getWritableDatabase();
        ContentValues icv = new ContentValues();
        icv.put("name", listData.getName());
        icv.put("winner",listData.getWinner());
        idb.insert("karbaran", null, icv);
        idb.close();


    }

    @SuppressLint("Range")
    public ArrayList getAllKarbaran(){

        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<MyListData> array_list = new ArrayList<MyListData>();
        Cursor res = db.rawQuery( "select * from karbaran", null );
        res.moveToFirst();
        while(res.isAfterLast() == false) {
            //array_list.add(res.getString(res.getColumnIndex("name")));

            array_list.add(new MyListData(res.getString(res.getColumnIndex("name")),res.getInt(res.getColumnIndex("winner")),res.getInt(res.getColumnIndex("kid"))));
            res.moveToNext();
        }
        return array_list;

    }

    public void deleteRaw(long delRaw){

        SQLiteDatabase db=this.getWritableDatabase();
         db.delete("karbaran","kid"+"="+delRaw, null);
    }
}
